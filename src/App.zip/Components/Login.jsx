import React, { useState } from "react";

import { Link, useNavigate } from "react-router-dom";



const API_BASE_URL = "http://localhost:8080/api";



const Login = () => {

 const navigate = useNavigate();

 const [email, setEmail] = useState("");

 const [password, setPassword] = useState("");

 const [showPassword, setShowPassword] = useState(false);

 const [error, setError] = useState("");



 const handleShowPassword = () => setShowPassword(!showPassword);



 const handleSubmit = async (e) => {

  e.preventDefault();

  setError("");



  try {

   const response = await fetch(`${API_BASE_URL}/auth/login`, {

    method: "POST",

    headers: {

     "Content-Type": "application/json",

    },

    body: JSON.stringify({ email, password }), // Use email and password only

   });



   const data = await response.json();



   if (response.ok) {

    switch (data.role) {

     case "admin":

      alert("Successful login as Admin");

      navigate("/admin");

      break;

     case "technician":

      alert("Successful login as Technician");

      navigate("/admin");

      break;

     default:

      alert("Successful login");

      navigate("/HomePage");

      break;

    }

   } else {

    alert(data.message || "Invalid credentials");

   }

  } catch (err) {

   console.error("Fetch error:", err);

   alert("Error connecting to the server.");

  }

 };



 const styles = {

  container: {

   display: "flex",

   justifyContent: "center",

   alignItems: "center",

   width: "100vw",

   height: "100vh",

   background: "linear-gradient(to top right, #0f2027, #203a43, #2c5364)",

   fontFamily: "'Poppins', sans-serif",

   color: "#ffffff",

  },

  card: {

   background: "linear-gradient(145deg, rgba(255, 255, 255, 0.15), rgba(0, 0, 0, 0.25))",

   padding: "40px",

   borderRadius: "12px",

   boxShadow: "0 8px 32px rgba(0, 0, 0, 0.5)",

   width: "350px",

   textAlign: "center",

   backdropFilter: "blur(10px)",

   border: "1px solid rgba(255, 255, 255, 0.2)",

  },

  heading: {

   marginBottom: "20px",

   fontSize: "26px",

   fontWeight: "600",

   textTransform: "uppercase",

   letterSpacing: "1px",

   color: "#ffd700",

  },

  inputGroup: {

   marginBottom: "20px",

   textAlign: "left",

  },

  label: {

   display: "block",

   marginBottom: "5px",

   fontSize: "14px",

   fontWeight: "500",

   color: "#eee",

  },

  input: {

   width: "100%",

   padding: "12px",

   border: "none",

   borderRadius: "8px",

   fontSize: "14px",

   background: "rgba(255, 255, 255, 0.15)",

   color: "#fff",

   borderBottom: "2px solid rgba(255, 255, 255, 0.3)",

   transition: "0.3s",

   outline: "none",

  },

  inputFocus: {

   borderBottom: "2px solid #ffd700",

  },

  showPassword: {

   marginTop: "8px",

   display: "flex",

   alignItems: "center",

   fontSize: "14px",

   color: "#ddd",

  },

  button: {

   width: "100%",

   padding: "12px",

   background: "linear-gradient(145deg, #ff8c00, #ffd700)",

   color: "#fff",

   border: "none",

   borderRadius: "8px",

   fontSize: "16px",

   fontWeight: "bold",

   cursor: "pointer",

   transition: "0.3s",

   boxShadow: "0 5px 15px rgba(255, 69, 0, 0.4)",

  },

  buttonHover: {

   background: "linear-gradient(145deg, #ff6347, #ff4500)",

  },

  error: {

   color: "#ff6b6b",

   backgroundColor: "rgba(255, 107, 107, 0.1)",

   padding: "10px",

   borderRadius: "5px",

   marginBottom: "15px",

   fontSize: "14px",

  },

  register: {

   marginTop: "15px",

   fontSize: "14px",

  },

  link: {

   color: "#ffd700",

   textDecoration: "none",

   fontWeight: "bold",

  },

 };



 return (

  <div style={styles.container}>

   <div style={styles.card}>

    <h2 style={styles.heading}>Welcome Again!</h2>

    {error && <div style={styles.error}>{error}</div>}

    <form onSubmit={handleSubmit}>

     <div style={styles.inputGroup}>

      <label style={styles.label}>Email</label>

      <input

       type="email"

       value={email}

       onChange={(e) => setEmail(e.target.value)}

       required

       style={styles.input}

       placeholder="Enter your email"

      />

     </div>

     <div style={styles.inputGroup}>

      <label style={styles.label}>Password</label>

      <input

       type={showPassword ? "text" : "password"}

       value={password}

       onChange={(e) => setPassword(e.target.value)}

       required

       style={styles.input}

       placeholder="Enter your password"

      />

      <div style={styles.showPassword}>

       <input type="checkbox" checked={showPassword} onChange={handleShowPassword} />

       <span>Show Password</span>

      </div>

     </div>

     <button type="submit" style={styles.button}>

      Login

     </button>

    </form>

    <p style={styles.register}>

     Not a user?{" "}

     <Link to="/register" style={styles.link}>

      Register here

     </Link>

    </p>

   </div>

  </div>

 );

};



export default Login;

