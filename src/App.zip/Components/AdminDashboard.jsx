import React, { useState } from "react";

import { useNavigate } from "react-router-dom";



function AdminDashboard() {

  const [showResetDialog, setShowResetDialog] = useState(false);

  const [passwords, setPasswords] = useState({

    currentPassword: "",

    newPassword: "",

    confirmPassword: "",

  });

  const [location, setLocation] = useState("");

  const navigate = useNavigate();



  const handlePasswordChange = (e) => {

    setPasswords({ ...passwords, [e.target.name]: e.target.value });

  };



  const handleResetPassword = () => {

    if (passwords.newPassword !== passwords.confirmPassword) {

      alert("New password and Confirm password must match!");

      return;

    }

    alert("Password reset successfully!");

    setShowResetDialog(false);

  };



  const handleLogout = () => {

    navigate("/login");

  };



  return (

    <div style={styles.container}>

      {/* Admin Header */}

      <div style={styles.header}>

        <h1 style={styles.heading}>Admin Dashboard</h1>

        <button style={styles.logoutBtn} onClick={handleLogout}>

          Logout

        </button>

      </div>



      {/* Location Dropdown */}

      <div style={styles.section}>

        <label style={styles.label}>Select Location:</label>

        <select

          style={styles.dropdown}

          value={location}

          onChange={(e) => setLocation(e.target.value)}

        >

          <option value="">Select a location</option>

          <option value="Mumbai">Mumbai</option>

          <option value="Hyderabad">Hyderabad</option>

          <option value="Bangalore">Bangalore</option>

          <option value="Pune">Pune</option>

          <option value="Chennai">Chennai</option>

        </select>

      </div>



      {/* Reset Password Button */}

      <button style={styles.resetBtn} onClick={() => setShowResetDialog(true)}>

        Reset Password

      </button>



      {/* Reset Password Dialog */}

      {showResetDialog && (

        <div style={styles.dialogOverlay}>

          <div style={styles.dialogBox}>

            <h2 style={styles.dialogTitle}>Reset Password</h2>

            <input

              type="password"

              name="currentPassword"

              placeholder="Current Password"

              style={styles.input}

              onChange={handlePasswordChange}

            />

            <input

              type="password"

              name="newPassword"

              placeholder="New Password"

              style={styles.input}

              onChange={handlePasswordChange}

            />

            <input

              type="password"

              name="confirmPassword"

              placeholder="Confirm Password"

              style={styles.input}

              onChange={handlePasswordChange}

            />

            <div style={styles.dialogButtons}>

              <button style={styles.cancelBtn} onClick={() => setShowResetDialog(false)}>

                Cancel

              </button>

              <button style={styles.confirmBtn} onClick={handleResetPassword}>

                Confirm

              </button>

            </div>

          </div>

        </div>

      )}

    </div>

  );

}



// Styles (Matching Login Page)

const styles = {

  container: {

    display: "flex",

    flexDirection: "column",

    alignItems: "center",

    justifyContent: "center",

    height: "100vh",

    background: "linear-gradient(to top right, #0f2027, #203a43, #2c5364)",

    fontFamily: "'Poppins', sans-serif",

  },

  header: {

    display: "flex",

    justifyContent: "space-between",

    alignItems: "center",

    width: "80%",

    padding: "20px",

    background: "rgba(255, 255, 255, 0.15)",

    borderRadius: "10px",

    boxShadow: "0 5px 15px rgba(0, 0, 0, 0.3)",

  },

  heading: {

    fontSize: "24px",

    fontWeight: "bold",

    color: "#FFD700",

  },

  logoutBtn: {

    padding: "10px 15px",

    background: "linear-gradient(145deg, #FF4500, #FF6347)",

    color: "#FFF",

    border: "none",

    borderRadius: "5px",

    cursor: "pointer",

    fontWeight: "bold",

  },

  section: {

    margin: "20px 0",

    width: "80%",

  },

  label: {

    display: "block",

    color: "#EEE",

    fontSize: "16px",

    marginBottom: "8px",

  },

  dropdown: {

    width: "100%",

    padding: "10px",

    borderRadius: "5px",

    fontSize: "16px",

    background: "rgba(255, 255, 255, 0.2)",

    color: "#FFF",

    border: "none",

    outline: "none",

  },

  resetBtn: {

    padding: "12px 20px",

    background: "linear-gradient(145deg, #FF8C00, #FFD700)",

    color: "#FFF",

    border: "none",

    borderRadius: "8px",

    fontSize: "16px",

    fontWeight: "bold",

    cursor: "pointer",

    boxShadow: "0 5px 15px rgba(255, 69, 0, 0.4)",

  },

  dialogOverlay: {

    position: "fixed",

    top: 0,

    left: 0,

    right: 0,

    bottom: 0,

    background: "rgba(0, 0, 0, 0.5)",

    display: "flex",

    alignItems: "center",

    justifyContent: "center",

  },

  dialogBox: {

    background: "#FFF",

    padding: "20px",

    borderRadius: "8px",

    textAlign: "center",

    width: "350px",

    boxShadow: "0 5px 15px rgba(0, 0, 0, 0.3)",

  },

  dialogTitle: {

    fontSize: "20px",

    marginBottom: "15px",

    color: "#333",

  },

  input: {

    width: "100%",

    padding: "10px",

    marginBottom: "10px",

    borderRadius: "5px",

    border: "1px solid #ccc",

  },

  dialogButtons: {

    display: "flex",

    justifyContent: "space-between",

  },

  cancelBtn: {

    padding: "8px 15px",

    background: "#aaa",

    border: "none",

    borderRadius: "5px",

    cursor:

 "pointer",

  },

  confirmBtn: {

    padding: "8px 15px",

    background: "green",

    color: "#FFF",

    border: "none",

    borderRadius: "5px",

    cursor: "pointer",

  },

};



export default AdminDashboard;